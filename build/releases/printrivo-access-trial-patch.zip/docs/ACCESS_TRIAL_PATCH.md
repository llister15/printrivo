# Demo/internal access and PayPal trial activation patch

Prepared September 22, 2026. Implemented and tested locally; not deployed to
printrivo.com. The exact cause for the reported production account is not yet
confirmed because its server/provider records have not been inspected.

## Deploy

1. Back up the corresponding application files on your host.
2. Extract `printrivo-access-trial-patch.zip` into the application root (the
   directory containing `app`, `docs`, and `spark`). Merge folders and replace
   the included files. Do not delete other files or replace `.env`.
3. No new database migration or PayPal plan is required. The existing
   subscriptions/trials/admin-actions migrations must already be installed.
4. If the host caches PHP code, reload PHP or clear its OPcache using the hosting
   panel's normal deployment procedure.
5. Have the affected member sign in and click **Check payment status**. An
   eligible trial now sends them to the dashboard and unlocks the tools.
   The original provider trial end is retained; this does not restart a trial.
6. If status remains incomplete, run `php spark paypal:inspect MEMBER_EMAIL`
   in the production application's terminal and inspect the safe output.
   See `docs/PAYPAL_SETUP.md` for the diagnostic fields. Do not share `.env`,
   PayPal secrets, access tokens, or raw customer provider responses.

This patch updates nine application files:

- `app/Commands/PayPalInspect.php`
- `app/Config/Routes.php`
- `app/Controllers/Admin.php`
- `app/Controllers/PayPal.php`
- `app/Services/ComplimentaryAccess.php`
- `app/Services/PayPalBilling.php`
- `app/Views/account/subscription.php`
- `app/Views/admin/user.php`
- `app/Views/dashboard.php`

## Grant a demo or internal account

Have the user register, stopping at payment setup. Sign in as an administrator,
open `/admin`, find the account, and choose **Manage → Demo and internal access**.
Choose the type and number of days, then **Grant complimentary access**.
The member can go directly to `/dashboard`. No payment information is needed.
Use **Revoke complimentary access** to remove the grant early.

If your owner account is not an administrator, run the existing server command:

```sh
php spark admin:grant YOUR_OWNER_EMAIL
```

Grants do not give admin permissions or cancel existing PayPal billing. They
expire automatically and record the administrator and action in the audit trail.

## Validation

- `php vendor/bin/phpunit --no-coverage`: 68 tests, 403 assertions passed.
- `node tests/js/builder.test.cjs`: passed.
- `tests/js/studio.browser.cjs` with installed Puppeteer/Chrome: passed.
- PHP syntax checks passed for changed services, controllers, command, and views.
- Updated one stale route-test expectation to match Image Studio's existing
  dark logo; no tool implementation or branding was changed.

Production checkout/return and signature-verified webhook delivery still need
acceptance testing against the actual agreement. The PHP billing tests mock
PayPal responses and do not prove live credentials or webhook delivery work.
