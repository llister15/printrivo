# Admin-created accounts, agreed prices, and subscription discounts

Implemented locally September 22, 2026. PayPal remains the billing provider.
No production accounts, emails, or PayPal billing changes were made while
developing this update. Automated PayPal tests use mocked provider responses.

## Install on your hosting account

This release includes the previous demo/internal-access and trial-activation
fixes. Back up your application files and production database before installing.

1. Pause web traffic using your host's maintenance controls.
2. Extract `printrivo-admin-members-update.zip` into the application root (the
   folder containing `app`, `public`, `docs`, and `spark`). Merge folders and
   replace included files. Do not delete other files or replace `.env`.
3. From the application's directory in the hosting terminal, run:

   ```sh
   php spark migrate --all
   ```

   If your plan has no terminal, ask your host to run this command. Uploading
   the files alone is not enough. Do not expose a public migration script.
4. Clear/reload the host's PHP OPcache if it caches old application files,
   then resume traffic.
5. Log in as an administrator and open `/admin`. Verify **Create member** and
   the new member management controls.

The migration adds `member_invitations`, `member_prices`, six subscription
discount fields, and permits account audit entries without a subscription ID.
It uses the configured database prefix. It has been run on the local MySQL
database and through the automated SQLite tests, not on production.

Keep the configured standard/Alpha PayPal plans; no new shared plan or additional
PayPal credentials are needed. Individual prices use subscription overrides.
Existing Email settings supply the SMTP server and verified sender. Email
success means submission to the mail server, not guaranteed inbox delivery.

## Create a member

Open **Admin → Create member**, then enter their name and email.

- **Paid monthly subscription:** set an agreed USD monthly amount from $0.01
  to $9.99. The offer appears in the invitation and account checkout. The member
  must authorize PayPal recurring payments themselves. Eligible new members
  retain the 14-day introductory trial. Creation never fabricates payment or
  grants paid access.
- **Free internal/demo access:** choose 1–3650 days. All tools are available
  without payment information; the grant expires automatically and can be
  revoked using the existing controls. Access starts when the admin creates it.

The member chooses their own password using a private setup link. Select the
email checkbox to send the invitation and terms. The admin also receives a
copyable setup link immediately after creation, including if SMTP fails.
The link expires after seven days and works once. Pending invitations can be
reissued from the member page, invalidating the previous link. Accepted
invitations cannot be reissued as a password-reset mechanism.

Tokens are random; only their SHA-256 hashes are stored in the invitation table.
The setup URL carries the token in its fragment, not the server request path or
query string. The page removes the fragment and submits it with the password
over the CSRF-protected POST. Password rules and hashing use Shield. No default
password is shown or emailed, and admin-created members never gain admin roles.

## Send an agreed-price offer to an existing account

On **Admin → Manage member**, use **Agreed price for a new subscription**.
Optionally email the offer. This is available when the account has no open
PayPal agreement. A pending checkout already has saved terms: finish or resolve
it before issuing a different offer.

The offer is a recurring subscription invitation, not a tax invoice or a payment
receipt. Payment is authorized through the existing PayPal checkout, and real
transactions remain available in billing history. A formal PayPal Invoicing
integration is not included.

Offers are specific to the member and PayPal environment, saved server-side,
and claimed by the checkout transaction. Browser-supplied prices cannot select
the charge amount. Changed/stale terms require reviewing checkout again.
The agreed price lasts while that subscription continues. After cancellation,
a replacement subscription needs a new offer or uses normal pricing rules.

## Discount an existing full-price subscription

Open **Admin → Manage member → Discount this subscription**. Enter a lower
positive monthly amount, confirm the change, and optionally notify the member.
Use **Check PayPal status** to reconcile delayed confirmation. A pending request
can be retried at the same amount; it never creates a second subscription.

This updates only the individual agreement's regular billing cycle. It does not
change the public/shared plan, move the billing date, issue a refund, restart a
trial, or cancel the agreement. Free access is a separate grant; if a paying
member should stop being billed entirely, cancel their PayPal renewal separately.

PayPal documents a ten-day notice window for PayPal-funded price changes:
payments due within that window retain the old price. The admin and member pages
explain this. The app does not claim the very next payment will always be lower.
Confirmed old-price payments continue granting their paid month during the
transition; later renewals must match the new amount. Failed, held, suspended,
or expired billing remains subject to existing entitlement checks.

Local price changes only after a server-side PayPal read confirms the requested
price on the matching agreement. An uncertain network result stays pending.
Webhooks, member refresh, and admin refresh all use the same confirmation code.
Another reduction is allowed after the previous price appears on a payment,
avoiding overlapping transition windows. The audit trail records the old/new
amounts in cents, administrator, member, agreement, and confirmation outcome.

## Acceptance checks on HTTPS sandbox staging

1. Create a free member, open the received link, set a strong password, log in,
   and open all tools. Confirm the link cannot be reused.
2. Create a paid member at a custom amount. Confirm the invitation and checkout
   agree, PayPal displays the correct recurring amount, and trial activation
   waits for remote confirmation of that price.
3. Discount an active sandbox subscription. Confirm only that agreement changes,
   access is preserved, and the admin/member prices reflect provider confirmation.
4. Check the actual next charge and discounted renewal, including the ten-day
   timing rule; verify signed webhook delivery and duplicate handling.
5. Confirm email delivery/spam placement, mobile usability, and cancellation.

Once PayPal has confirmed a discount, do not simply restore older billing code:
it may reject payments at the new amount. Preserve the migration and discount
records, and reconcile provider billing before planning a rollback.

Provider references:

- [Per-subscription price updates](https://developer.paypal.com/api/subscriptions/v1/subscriptions-patch/)
- [Checkout plan overrides](https://developer.paypal.com/api/subscriptions/v1/subscriptions-create/)
- [Subscription details with plan fields](https://developer.paypal.com/api/subscriptions/v1/subscriptions-get/)
