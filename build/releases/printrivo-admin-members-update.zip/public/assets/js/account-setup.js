(() => {
    'use strict';
    const token = window.location.hash.slice(1);
    // Remove the secret before navigating or loading any subsequent page.
    history.replaceState(null, '', window.location.pathname);
    if (!/^[a-f0-9]{64}$/.test(token)) {
        document.getElementById('setup-link-error').hidden = false;
        return;
    }
    document.getElementById('setup-token').value = token;
    document.getElementById('setup-submit').disabled = false;
})();
