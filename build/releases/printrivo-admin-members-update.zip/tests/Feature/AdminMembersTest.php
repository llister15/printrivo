<?php
use App\Models\UserModel;
use App\Services\AdminMembers;
use App\Services\MemberMailer;
use App\Services\MemberPrice;
use App\Services\SubscriptionAccess;
use CodeIgniter\Shield\Entities\User;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use CodeIgniter\Test\FeatureTestTrait;
use CodeIgniter\Shield\Test\AuthenticationTesting;

final class AdminMembersTest extends CIUnitTestCase
{
    use DatabaseTestTrait, FeatureTestTrait, AuthenticationTesting;
    protected $namespace=null;
    protected $refresh=true;
    private function admin(): User
    {
        $users=model(UserModel::class);
        $users->save(new User(['email'=>'owner@example.test','first_name'=>'Owner','last_name'=>'Test','password'=>'LongExamplePassword!99','active'=>1]));
        $user=$users->findById($users->getInsertID()); $user->addGroup('admin'); return $user;
    }
    private function data(string $access='internal'): array
    {
        return ['email'=>'invite@example.test','first_name'=>'Invited','last_name'=>'Member','access'=>$access,'amount'=>'6.49','days'=>'365'];
    }
    protected function tearDown(): void { auth()->logout(); parent::tearDown(); }
    public function testAdminCreatesFreeMemberWhoSetsPasswordAndUsesTools(): void
    {
        $admin=$this->admin(); $this->actingAs($admin);
        $mailer=$this->createMock(MemberMailer::class); $mailer->expects($this->once())->method('send')->willReturn(false);
        \Config\Services::injectMock('memberMailer',$mailer);
        $this->get('/admin')->assertSee('Create member');
        $this->get('/admin/users/create')->assertOK();
        $this->post('/admin/users/create',$this->data()+['send_invitation'=>'1',csrf_token()=>csrf_hash(),'groups'=>['admin']])->assertRedirect();
        $user=model(UserModel::class)->findByCredentials(['email'=>'invite@example.test']);
        $this->assertNotNull($user); $this->assertFalse($user->inGroup('admin'));
        $this->assertStringContainsString('could not be sent',session('admin_message'));
        $link=session('member_setup')['link']; $token=parse_url($link,PHP_URL_FRAGMENT);
        $stored=$this->db->table('member_invitations')->where('user_id',$user->id)->get()->getRowArray();
        $this->assertSame(hash('sha256',$token),$stored['token_hash']);
        $this->assertSame('internal',(new SubscriptionAccess())->activeFor($user->id)['provider']);
        $this->withSession(['member_setup'=>['user_id'=>(int)$user->id,'link'=>$link]])->get('/admin/users/'.$user->id)->assertSee('Private password setup link');
        auth()->logout();
        $this->get('/account/setup')->assertOK();
        $this->post('/account/setup',['token'=>$token,'password'=>'B7!qN4zT9vL2xR8sW6','password_confirm'=>'B7!qN4zT9vL2xR8sW6',csrf_token()=>csrf_hash()])
            ->assertRedirectTo(site_url('login'));
        $this->post('/login',['email'=>'invite@example.test','password'=>'B7!qN4zT9vL2xR8sW6',csrf_token()=>csrf_hash()])->assertRedirectTo(site_url('dashboard'));
        foreach (['/tools/qr','/tools/gang-sheet','/tools/image-studio'] as $path) { $this->get($path)->assertOK(); }
        $this->get('/admin')->assertStatus(403);
        $this->expectException(RuntimeException::class);
        (new AdminMembers())->accept($token,'AnotherSecure!Pass567');
    }
    public function testPaidInvitationSavesPriceWithoutSubscriptionOrPayment(): void
    {
        $admin=$this->admin();
        $result=(new AdminMembers())->create($admin->id,$this->data('paid'));
        $user=$result['user'];
        $this->assertSame(649,(int)(new MemberPrice())->available($user->id)['amount']);
        $this->assertNull((new SubscriptionAccess())->activeFor($user->id));
        $this->assertSame(0,$this->db->table('subscriptions')->countAllResults());
        $this->actingAs($user);
        $page=$this->get('/account/subscription'); $page->assertSee('$6.49 USD/month');
        $this->assertStringContainsString('name="price_offer" value="649"',$page->response()->getBody());
        $this->get('/tools/qr')->assertRedirectTo(site_url('account/subscription'));
    }
    public function testInvitationReissueExpiryAndAcceptedAccountProtection(): void
    {
        $admin=$this->admin(); $members=new AdminMembers(); $result=$members->create($admin->id,$this->data());
        $old=parse_url($result['link'],PHP_URL_FRAGMENT);
        $new=parse_url($members->issue($admin->id,$result['user']->id),PHP_URL_FRAGMENT);
        try { $members->accept($old,'B7!qN4zT9vL2xR8sW6'); $this->fail('Old link accepted'); } catch (RuntimeException) {}
        $this->db->table('member_invitations')->where('user_id',$result['user']->id)->update(['expires_at'=>'2000-01-01 00:00:00']);
        try { $members->accept($new,'B7!qN4zT9vL2xR8sW6'); $this->fail('Expired link accepted'); } catch (RuntimeException) {}
        $new=parse_url($members->issue($admin->id,$result['user']->id),PHP_URL_FRAGMENT);
        try { $members->accept($new,'weak'); $this->fail('Weak password accepted'); } catch (InvalidArgumentException) {}
        $members->accept($new,'B7!qN4zT9vL2xR8sW6');
        $this->expectException(RuntimeException::class);
        $members->issue($admin->id,$result['user']->id);
    }
    public function testAdminEndpointsRejectMembersAndMissingCsrf(): void
    {
        $admin=$this->admin(); $result=(new AdminMembers())->create($admin->id,$this->data());
        $this->get('/admin/users/create')->assertRedirectTo(site_url('login'));
        $this->actingAs($result['user']);
        foreach (['create',''.$admin->id.'/invite',''.$admin->id.'/price',''.$admin->id.'/discount',''.$admin->id.'/refresh'] as $path) {
            $this->post('/admin/users/'.$path,[csrf_token()=>csrf_hash()])->assertStatus(403);
        }
        $this->actingAs($admin);
        try { $this->post('/admin/users/create',$this->data()); $this->fail('Missing CSRF accepted'); }
        catch (\CodeIgniter\Security\Exceptions\SecurityException $e) { $this->assertSame(403,$e->getCode()); }
        $this->post('/admin/users/create',$this->data()+[csrf_token()=>csrf_hash()])->assertRedirectTo(site_url('admin/users/create'));
        $this->assertSame(2,$this->db->table('users')->countAllResults());
    }
    public function testPriceValidationRejectsZeroIncreasesAndArrayInput(): void
    {
        foreach (['0','10.00','-1','1.234','1e2',[],null] as $amount) {
            try { MemberPrice::amount($amount); $this->fail('Invalid price accepted'); } catch (InvalidArgumentException) {}
        }
        $this->assertSame(499,MemberPrice::amount('4.99'));
        $this->assertSame(1,MemberPrice::amount('0.01'));
    }
    public function testInvitationEmailIncludesAgreedRateAndPrivateSetupLink(): void
    {
        $admin=$this->admin(); $members=new AdminMembers(); $result=$members->create($admin->id,$this->data('paid'));
        $mailer=$this->createMock(MemberMailer::class);
        $mailer->expects($this->once())->method('send')->willReturnCallback(function($email,$subject,$body) {
            $this->assertSame('invite@example.test',$email);
            $this->assertStringContainsString('$6.49 USD/month',$body);
            $this->assertStringContainsString(site_url('account/setup').'#',$body);
            $this->assertStringContainsString('does not charge you or confirm payment',$body);
            $this->assertStringNotContainsString('password=',$body);
            return true;
        });
        \Config\Services::injectMock('memberMailer',$mailer);
        $this->assertTrue($members->sendInvitation($result['user'],$result['link']));
    }
}
