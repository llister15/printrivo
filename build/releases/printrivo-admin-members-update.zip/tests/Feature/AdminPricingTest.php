<?php
use App\Models\UserModel;
use App\Services\MemberPrice;
use App\Services\PayPalBilling;
use App\Services\PayPalClient;
use App\Services\SubscriptionAccess;
use CodeIgniter\Shield\Entities\User;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use CodeIgniter\Test\FeatureTestTrait;
use CodeIgniter\Shield\Test\AuthenticationTesting;

final class AdminPricingTest extends CIUnitTestCase
{
    use DatabaseTestTrait, FeatureTestTrait, AuthenticationTesting;
    protected $namespace=null;
    protected $refresh=true;
    private array $original=[];
    protected function setUp(): void
    {
        parent::setUp();
        foreach (['enabled'=>true,'environment'=>'sandbox','clientId'=>'test','secret'=>'test','webhookId'=>'test',
            'standardPlanId'=>'P-STANDARD','alphaPlanId'=>'P-ALPHA','standardTrialPlanId'=>'','alphaTrialPlanId'=>'','trialHashKey'=>''] as $key=>$value) {
            $this->original[$key]=config('PayPal')->$key; config('PayPal')->$key=$value;
        }
    }
    protected function tearDown(): void
    {
        auth()->logout(); foreach ($this->original as $key=>$value) { config('PayPal')->$key=$value; } parent::tearDown();
    }
    private function user(string $email,bool $admin=false): User
    {
        $users=model(UserModel::class);
        $users->save(new User(['email'=>$email,'first_name'=>'Test','last_name'=>'Member','password'=>'B7!qN4zT9vL2xR8sW6','active'=>1]));
        $user=$users->findById($users->getInsertID()); if ($admin) { $user->addGroup('admin'); } return $user;
    }
    private function row(User $user): array
    {
        $this->db->table('subscriptions')->insert(['user_id'=>$user->id,'provider'=>'paypal','provider_environment'=>'sandbox',
            'provider_subscription_id'=>'I-TEST','provider_price_id'=>'P-STANDARD','paypal_reference'=>'test-ref','billing_amount'=>999,
            'billing_currency'=>'USD','status'=>'active','current_period_start'=>gmdate('Y-m-d H:i:s',time()-86400),
            'current_period_end'=>gmdate('Y-m-d H:i:s',time()+29*86400)]);
        return $this->db->table('subscriptions')->where('id',$this->db->insertID())->get()->getRowArray();
    }
    private function details(int $price=999,int $paid=999): array
    {
        return ['id'=>'I-TEST','plan_id'=>'P-STANDARD','custom_id'=>'test-ref','status'=>'ACTIVE',
            'plan'=>['billing_cycles'=>[['sequence'=>1,'tenure_type'=>'REGULAR','pricing_scheme'=>['fixed_price'=>['currency_code'=>'USD','value'=>number_format($price/100,2,'.','')]]]]],
            'billing_info'=>['last_payment'=>['time'=>gmdate('c',time()-86400),'amount'=>['value'=>number_format($paid/100,2,'.',''),'currency_code'=>'USD']],
                'next_billing_time'=>gmdate('c',time()+29*86400),'failed_payments_count'=>0,'outstanding_balance'=>['value'=>'0.00']]];
    }
    public function testDiscountChangesOnlyAgreementPreservesOldPaidMonthAndAcceptsNewRenewal(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $changed=false; $client=$this->createMock(PayPalClient::class);
        $client->method('request')->willReturnCallback(function($method,$path,$body=null) use (&$changed) {
            if ($method==='PATCH') {
                $this->assertSame('/v1/billing/subscriptions/I-TEST',$path);
                $this->assertSame('/plan/billing_cycles/@sequence==1/pricing_scheme/fixed_price',$body[0]['path']);
                $this->assertSame(['currency_code'=>'USD','value'=>'4.99'],$body[0]['value']); $changed=true; return [];
            }
            $this->assertStringEndsWith('?fields=plan',$path);
            return $this->details($changed?499:999);
        });
        $billing=new PayPalBilling($client); $billing->discount($admin->id,$user->id,$row['id'],499);
        $access=(new SubscriptionAccess())->activeFor($user->id);
        $this->assertNotNull($access); $this->assertSame(499,(int)$access['billing_amount']);
        $this->assertSame($row['current_period_end'],$access['current_period_end']);
        $this->assertSame('confirmed',$this->db->table('admin_actions')->get()->getRowArray()['outcome']);
        $renewal=$this->details(499,499); $renewal['billing_info']['last_payment']['time']=gmdate('c');
        $client2=$this->createMock(PayPalClient::class); $client2->method('request')->willReturn($renewal);
        (new PayPalBilling($client2))->refresh($user->id);
        $this->assertNotNull((new SubscriptionAccess())->activeFor($user->id));
        $this->assertSame(1,$this->db->table('subscriptions')->countAllResults());
    }
    public function testUnconfirmedDiscountCannotChangeLocalPriceAndTimeoutIsSafelyReconciled(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $client=$this->createMock(PayPalClient::class);
        $client->method('request')->willReturnCallback(function($method) {
            if ($method==='PATCH') { throw new RuntimeException('Timeout'); } return $this->details();
        });
        try { (new PayPalBilling($client))->discount($admin->id,$user->id,$row['id'],499); $this->fail('Timeout hidden'); } catch (RuntimeException) {}
        $pending=(new PayPalBilling())->latest($user->id);
        $this->assertSame(999,(int)$pending['billing_amount']); $this->assertNull($pending['discount_confirmed_at']);
        $this->assertNotNull((new SubscriptionAccess())->activeFor($user->id));
        $confirmed=$this->createMock(PayPalClient::class);
        $confirmed->expects($this->once())->method('request')->with('GET','/v1/billing/subscriptions/I-TEST?fields=plan')->willReturn($this->details(499));
        (new PayPalBilling($confirmed))->retryDiscount($admin->id,$user->id,$row['id']);
        $this->assertSame(499,(int)(new PayPalBilling())->latest($user->id)['billing_amount']);
    }
    public function testOldPriceAfterNoticeWindowAndFailedPaymentsCannotUnlockTools(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $this->db->table('subscriptions')->where('id',$row['id'])->update(['billing_amount'=>499,'discount_amount'=>499,
            'previous_billing_amount'=>999,'discount_confirmed_at'=>gmdate('Y-m-d H:i:s',time()-20*86400),
            'discount_old_price_until'=>gmdate('Y-m-d H:i:s',time()-10*86400)]);
        foreach (['late','failed','suspended'] as $case) {
            $details=$this->details(499,$case==='late'?999:499);
            if ($case==='failed') { $details['billing_info']['failed_payments_count']=1; }
            if ($case==='suspended') { $details['status']='SUSPENDED'; }
            $client=$this->createMock(PayPalClient::class); $client->method('request')->willReturn($details);
            (new PayPalBilling($client))->refresh($user->id);
            $this->assertNull((new SubscriptionAccess())->activeFor($user->id),$case);
        }
    }
    public function testInvalidDiscountsAndStaleAgreementDoNotContactPayPal(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $client=$this->createMock(PayPalClient::class); $client->expects($this->never())->method('request');
        $billing=new PayPalBilling($client);
        foreach ([[0,$row['id']],[999,$row['id']],[1000,$row['id']],[499,$row['id']+1]] as [$amount,$id]) {
            try { $billing->discount($admin->id,$user->id,$id,$amount); $this->fail('Invalid discount accepted'); } catch (RuntimeException) {}
        }
        try { $billing->discount($user->id,$user->id,$row['id'],499); $this->fail('Non-admin accepted'); } catch (RuntimeException) {}
        $this->db->table('subscriptions')->where('id',$row['id'])->update(['cancel_at_period_end'=>1]);
        $this->expectException(RuntimeException::class); $billing->discount($admin->id,$user->id,$row['id'],499);
    }
    public function testAgreedPriceIsAppliedServerSideAtCheckoutAndStaleConsentIsRejected(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test');
        (new MemberPrice())->set($admin->id,$user->id,649);
        $body=[]; $client=$this->createMock(PayPalClient::class);
        $client->method('request')->willReturnCallback(function($method,$path,$payload=null) use (&$body) {
            if ($method==='GET') {
                return ['status'=>'ACTIVE','billing_cycles'=>[['tenure_type'=>'REGULAR','sequence'=>1,
                    'frequency'=>['interval_unit'=>'MONTH','interval_count'=>1],'total_cycles'=>0,
                    'pricing_scheme'=>['fixed_price'=>['value'=>'9.99','currency_code'=>'USD']]]]];
            }
            $body=$payload; return ['id'=>'I-TEST','links'=>[['rel'=>'approve','href'=>'https://www.sandbox.paypal.com/approve']]];
        });
        $billing=new PayPalBilling($client);
        try { $billing->checkout($user,false,999); $this->fail('Stale consent accepted'); } catch (RuntimeException) {}
        $this->assertSame(0,$this->db->table('subscriptions')->countAllResults());
        $billing->checkout($user,false,649);
        $this->assertSame('P-STANDARD',$body['plan_id']);
        $this->assertSame('6.49',$body['plan']['billing_cycles'][0]['pricing_scheme']['fixed_price']['value']);
        $this->assertNull((new MemberPrice())->available($user->id));
        $this->assertNull((new SubscriptionAccess())->activeFor($user->id));
        $this->expectException(RuntimeException::class); (new MemberPrice())->set($admin->id,$user->id,499);
    }
    public function testAdminDiscountRouteRequiresConfirmationAndReportsUnconfirmedProviderState(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $calls=0; $client=$this->createMock(PayPalClient::class);
        $client->method('request')->willReturnCallback(function($method) use (&$calls) {
            if ($method==='PATCH') { $calls++; return []; } return $this->details();
        });
        \Config\Services::injectMock('paypalClient',$client); $this->actingAs($admin);
        $route='/admin/users/'.$user->id.'/discount';
        $this->post($route,['subscription_id'=>(string)$row['id'],'amount'=>'4.99',csrf_token()=>csrf_hash()])->assertRedirect();
        $this->assertSame(0,$calls);
        $this->post($route,['subscription_id'=>(string)$row['id'],'amount'=>'4.99','confirm'=>'1',csrf_token()=>csrf_hash()])->assertRedirect();
        $this->assertSame(1,$calls);
        $this->assertStringContainsString('confirmation is pending',session('admin_message'));
        $this->assertSame(999,(int)(new PayPalBilling())->latest($user->id)['billing_amount']);
        $this->get('/admin/users/'.$user->id)->assertSee('Confirmation pending');
    }
    public function testWebhookConfirmsDiscountIdempotentlyAndEnvironmentDoesNotLeak(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $this->db->table('subscriptions')->where('id',$row['id'])->update(['discount_amount'=>499,'previous_billing_amount'=>999,
            'discount_requested_at'=>gmdate('Y-m-d H:i:s'),'discount_admin_id'=>$admin->id]);
        $client=$this->createMock(PayPalClient::class); $client->method('verify')->willReturn(true);
        $client->expects($this->once())->method('request')->willReturn($this->details(499));
        $billing=new PayPalBilling($client);
        $event=['id'=>'WH-DISCOUNT','event_type'=>'BILLING.SUBSCRIPTION.UPDATED','create_time'=>gmdate('c'),'resource'=>['id'=>'I-TEST']];
        $billing->webhook([],$event); $billing->webhook([],$event);
        $this->assertSame(499,(int)$billing->latest($user->id)['billing_amount']);
        $this->assertSame(1,$this->db->table('payment_events')->countAllResults());
        config('PayPal')->environment='live';
        $this->assertNull($billing->latest($user->id));
        $this->assertNull((new SubscriptionAccess())->activeFor($user->id));
    }
    public function testDiscountDuringTrialUsesRegularSequenceAndPreservesTrialEnd(): void
    {
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test'); $row=$this->row($user);
        $end=gmdate('Y-m-d H:i:s',time()+7*86400);
        $this->db->table('subscriptions')->where('id',$row['id'])->update(['status'=>'trialing','trial_requested'=>1,
            'trial_ends_at'=>$end,'current_period_end'=>$end,'current_period_start'=>null]);
        $changed=false; $client=$this->createMock(PayPalClient::class);
        $client->method('request')->willReturnCallback(function($method,$path,$body=null) use (&$changed,$end) {
            if ($method==='PATCH') {
                $this->assertSame('/plan/billing_cycles/@sequence==2/pricing_scheme/fixed_price',$body[0]['path']);
                $changed=true; return [];
            }
            $details=$this->details($changed?499:999); unset($details['billing_info']['last_payment']);
            $details['billing_info']['next_billing_time']=gmdate('c',strtotime($end.' UTC'));
            $details['plan']['billing_cycles'][0]['sequence']=2; return $details;
        });
        (new PayPalBilling($client))->discount($admin->id,$user->id,$row['id'],499);
        $access=(new SubscriptionAccess())->activeFor($user->id);
        $this->assertSame('trialing',$access['status']); $this->assertSame($end,$access['trial_ends_at']);
        $this->assertSame(499,(int)$access['billing_amount']);
    }
    public function testCustomTrialRequiresProviderPriceConfirmationAndCannotRestartOffer(): void
    {
        config('PayPal')->trialHashKey=str_repeat('x',64);
        $admin=$this->user('owner@example.test',true); $user=$this->user('member@example.test');
        (new MemberPrice())->set($admin->id,$user->id,649);
        $row=$this->row($user);
        $this->db->table('member_prices')->where('user_id',$user->id)->update(['subscription_id'=>$row['id']]);
        $this->db->table('subscriptions')->where('id',$row['id'])->update(['status'=>'incomplete','billing_amount'=>649,'trial_requested'=>1,
            'current_period_start'=>null,'current_period_end'=>null]);
        $details=$this->details(649); unset($details['billing_info']['last_payment']);
        $details['start_time']=gmdate('c',time()-3600); $details['subscriber']=['payer_id'=>'PAYER-NEW'];
        $details['billing_info']['next_billing_time']=gmdate('c',time()-3600+14*86400);
        $details['billing_info']['cycle_executions']=[['tenure_type'=>'TRIAL','sequence'=>1,'total_cycles'=>1]];
        $details['plan']['billing_cycles'][0]['sequence']=2;
        foreach ([999,649] as $amount) {
            $details['plan']['billing_cycles'][0]['pricing_scheme']['fixed_price']['value']=number_format($amount/100,2,'.','');
            $client=$this->createMock(PayPalClient::class); $client->method('request')->willReturn($details);
            (new PayPalBilling($client))->refresh($user->id);
            if ($amount===999) { $this->assertNull((new SubscriptionAccess())->activeFor($user->id)); }
            else { $this->assertSame('trialing',(new SubscriptionAccess())->activeFor($user->id)['status']); }
        }
        $this->assertNull((new MemberPrice())->available($user->id));
        config('PayPal')->environment='live';
        $this->assertNull((new MemberPrice())->available($user->id));
    }
}
