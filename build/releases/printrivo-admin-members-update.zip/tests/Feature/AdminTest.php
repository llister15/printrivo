<?php
use App\Models\UserModel;
use App\Services\PayPalClient;
use CodeIgniter\Shield\Entities\User;
use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\DatabaseTestTrait;
use CodeIgniter\Test\FeatureTestTrait;
use CodeIgniter\Shield\Test\AuthenticationTesting;
final class AdminTest extends CIUnitTestCase
{
    use DatabaseTestTrait, FeatureTestTrait, AuthenticationTesting;
    protected $namespace=null;
    protected $refresh=true;
    private function user(string $email,bool $admin=false): User
    {
        $model=model(UserModel::class);
        $user=new User(['email'=>$email,'password'=>'LongExamplePassword!99','first_name'=>'Test','last_name'=>'Member','active'=>1]);
        $model->save($user); $user=$model->findById($model->getInsertID());
        if ($admin) { $user->addGroup('admin'); }
        return $user;
    }
    protected function tearDown(): void { auth()->logout(); parent::tearDown(); }
    public function testAdminRoutesRejectVisitorsAndMembers(): void
    {
        $this->get('/admin')->assertRedirectTo(site_url('login'));
        $member=$this->user('member@example.test'); $this->actingAs($member);
        $this->get('/admin')->assertStatus(403);
        $this->get('/admin/users/'.$member->id)->assertStatus(403);
        $this->post('/admin/users/'.$member->id.'/cancel',[csrf_token()=>csrf_hash(),'confirm'=>'1','subscription_id'=>'1'])->assertStatus(403);
        $this->assertSame(0,$this->db->table('admin_actions')->countAllResults());
    }
    public function testAdminCanSearchUsersAndCountUniqueEligibleAccounts(): void
    {
        $admin=$this->user('owner@example.test',true); $member=$this->user('customer@example.test');
        foreach ([1,2] as $n) { $this->db->table('subscriptions')->insert(['user_id'=>$member->id,'provider'=>'test','status'=>'active','current_period_end'=>gmdate('Y-m-d H:i:s',time()+86400)]); }
        $this->actingAs($admin);
        $result=$this->get('/admin'); $result->assertOK(); $result->assertSee('Active members');
        $this->assertStringContainsString('<span>Active members</span><strong>1</strong>',$result->response()->getBody());
        $this->get('/admin?q=customer')->assertSee('customer@example.test');
        $this->get('/admin?q=nonexistent')->assertSee('No users match');
        $this->get('/admin/users/'.$member->id)->assertOK();
        $this->expectException(\CodeIgniter\Exceptions\PageNotFoundException::class);
        $this->get('/admin/users/999999');
    }
    private function agreement(User $user): int
    {
        $this->db->table('subscriptions')->insert(['user_id'=>$user->id,'provider'=>'paypal','provider_environment'=>config('PayPal')->environment,
            'provider_subscription_id'=>'I-TEST','provider_price_id'=>'P-STANDARD','paypal_reference'=>'ref-test',
            'billing_amount'=>999,'billing_currency'=>'USD','status'=>'active','current_period_end'=>gmdate('Y-m-d H:i:s',time()+86400)]);
        return (int)$this->db->insertID();
    }
    public function testCancellationRequiresConfirmationAndCurrentAgreement(): void
    {
        $admin=$this->user('owner@example.test',true);$member=$this->user('customer@example.test');$id=$this->agreement($member);
        $client=$this->createMock(PayPalClient::class);$client->expects($this->never())->method('request');
        \Config\Services::injectMock('paypalClient',$client);$this->actingAs($admin);
        foreach ([['subscription_id'=>(string)$id],['subscription_id'=>(string)($id+1),'confirm'=>'1']] as $data) {
            $this->post('/admin/users/'.$member->id.'/cancel',$data+[csrf_token()=>csrf_hash()])->assertRedirect();
        }
        $this->assertSame(0,$this->db->table('admin_actions')->countAllResults());
    }
    public function testConfirmedCancellationIsAuditedAndPreservesAccess(): void
    {
        $admin=$this->user('owner@example.test',true);$member=$this->user('customer@example.test');$id=$this->agreement($member);
        $canceled=false; $client=$this->createMock(PayPalClient::class);
        $client->expects($this->exactly(3))->method('request')->willReturnCallback(function($method,$path) use (&$canceled) {
            if ($method==='POST') { $this->assertStringEndsWith('/I-TEST/cancel',$path);$canceled=true;return []; }
            return ['id'=>'I-TEST','plan_id'=>'P-STANDARD','custom_id'=>'ref-test','status'=>$canceled?'CANCELLED':'ACTIVE',
                'billing_info'=>['last_payment'=>['time'=>gmdate('c',time()-3600),'amount'=>['value'=>'9.99','currency_code'=>'USD']],
                'failed_payments_count'=>0,'outstanding_balance'=>['value'=>'0.00']]];
        });
        \Config\Services::injectMock('paypalClient',$client);$this->actingAs($admin);
        $this->post('/admin/users/'.$member->id.'/cancel',[csrf_token()=>csrf_hash(),'subscription_id'=>(string)$id,'confirm'=>'1'])->assertRedirect();
        $audit=$this->db->table('admin_actions')->get()->getRowArray();
        $this->assertSame('confirmed',$audit['outcome']);$this->assertEquals($admin->id,$audit['admin_id']);
        $row=$this->db->table('subscriptions')->where('id',$id)->get()->getRowArray();
        $this->assertEquals(1,$row['cancel_at_period_end']);
        $this->assertNotNull((new \App\Services\SubscriptionAccess())->activeFor($member->id));
    }
    public function testProviderFailureIsNotReportedAsSuccess(): void
    {
        $admin=$this->user('owner@example.test',true);$member=$this->user('customer@example.test');$id=$this->agreement($member);
        $client=$this->createMock(PayPalClient::class);$client->method('request')->willThrowException(new RuntimeException('timeout'));
        \Config\Services::injectMock('paypalClient',$client);$this->actingAs($admin);
        $this->post('/admin/users/'.$member->id.'/cancel',[csrf_token()=>csrf_hash(),'subscription_id'=>(string)$id,'confirm'=>'1'])->assertRedirect();
        $this->assertSame('unconfirmed',$this->db->table('admin_actions')->get()->getRowArray()['outcome']);
        $this->assertStringContainsString('could not be confirmed',session('admin_error'));
    }
    public function testComplimentaryGrantUnlocksToolsAndRevocationIsAudited(): void
    {
        $admin=$this->user('owner@example.test',true); $member=$this->user('demo@example.test');
        $this->actingAs($admin);
        $this->post('/admin/users/'.$member->id.'/access',[csrf_token()=>csrf_hash(),'kind'=>'demo','days'=>'30'])->assertRedirect();
        $grant=(new \App\Services\ComplimentaryAccess())->current($member->id);
        $this->assertSame('demo',$grant['provider']);
        $this->assertNull($grant['provider_customer_id']);
        $this->get('/admin/users/'.$member->id)->assertSee('Demo access');
        $this->actingAs($member);
        foreach (['/tools/qr','/tools/gang-sheet','/tools/image-studio','/qrcode','/dtf/builder.php','/cleanimg'] as $route) {
            $this->get($route)->assertOK();
        }
        $this->get('/account/subscription')->assertSee('Your complimentary access is active.');
        $this->get('/dashboard')->assertSee('Demo access active');
        $this->get('/admin')->assertStatus(403);
        $this->db->table('subscriptions')->where('id',$grant['id'])->update(['current_period_end'=>gmdate('Y-m-d H:i:s',time()-1)]);
        $this->get('/tools/image-studio')->assertRedirectTo(site_url('account/subscription'));
        $this->db->table('subscriptions')->where('id',$grant['id'])->update(['current_period_end'=>gmdate('Y-m-d H:i:s',time()+86400)]);
        $this->actingAs($admin);
        $this->post('/admin/users/'.$member->id.'/access',[csrf_token()=>csrf_hash(),'kind'=>'revoke'])->assertRedirect();
        $this->assertNull((new \App\Services\SubscriptionAccess())->activeFor($member->id));
        $this->assertSame(2,$this->db->table('admin_actions')->where('user_id',$member->id)->countAllResults());
        $this->actingAs($member);
        $this->get('/tools/qr')->assertRedirectTo(site_url('account/subscription'));
    }
    public function testComplimentaryAccessRequiresAdminCsrfAndValidDuration(): void
    {
        $admin=$this->user('owner@example.test',true); $member=$this->user('demo@example.test');
        $route='/admin/users/'.$member->id.'/access';
        $data=['kind'=>'internal','days'=>'365'];
        $this->post($route,$data+[csrf_token()=>csrf_hash()])->assertStatus(401);
        $this->actingAs($member);
        $this->post($route,$data+[csrf_token()=>csrf_hash()])->assertStatus(403);
        $this->actingAs($admin);
        try { $this->post($route,$data); $this->fail('CSRF missing'); }
        catch (\CodeIgniter\Security\Exceptions\SecurityException $e) { $this->assertSame(403,$e->getCode()); }
        foreach ([['kind'=>'paypal','days'=>'30'],['kind'=>'demo','days'=>'0'],['kind'=>'internal','days'=>'3651'],['kind'=>['demo'],'days'=>'30']] as $invalid) {
            $this->post($route,$invalid+[csrf_token()=>csrf_hash()])->assertRedirect();
        }
        $this->assertSame(0,$this->db->table('subscriptions')->countAllResults());
        $this->db->table('users')->where('id',$member->id)->update(['active'=>0]);
        $this->post($route,$data+[csrf_token()=>csrf_hash()])->assertRedirect();
        $this->assertSame(0,$this->db->table('subscriptions')->countAllResults());
    }
    public function testInternalAccessExpiresAndDoesNotModifyPayPalBilling(): void
    {
        $admin=$this->user('owner@example.test',true); $member=$this->user('internal@example.test');
        $paypal=$this->agreement($member);
        $before=$this->db->table('subscriptions')->where('id',$paypal)->get()->getRowArray();
        $service=new \App\Services\ComplimentaryAccess();
        $service->change($admin->id,$member->id,'internal',365);
        $grant=$service->current($member->id);
        $this->assertSame('internal',$grant['provider']);
        $this->db->table('subscriptions')->where('id',$grant['id'])->update(['current_period_end'=>gmdate('Y-m-d H:i:s',time()-1)]);
        $this->assertNull($service->current($member->id));
        $service->change($admin->id,$member->id,'revoke');
        $this->assertSame($before,$this->db->table('subscriptions')->where('id',$paypal)->get()->getRowArray());
        $this->assertSame('paypal',(new \App\Services\SubscriptionAccess())->activeFor($member->id)['provider']);
    }
}
