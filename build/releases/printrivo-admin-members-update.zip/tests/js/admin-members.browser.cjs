const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const assert = require('assert/strict');
const root = path.resolve(__dirname, '../..');
const template = name => fs.readFileSync(path.join(root, 'app/Views', name), 'utf8')
    .replace(/<\?[\s\S]*?\?>/g, '').replace(/<script[^>]*>[\s\S]*?<\/script>/g, '')
    .replace(/<link[^>]*>/g, '');
(async () => {
    const browser = await puppeteer.launch({executablePath: process.env.CHROME_PATH || '/usr/bin/google-chrome', headless: true, args: ['--no-sandbox']});
    try {
        const page = await browser.newPage();
        const errors = [];
        page.on('pageerror', error => errors.push(error.message));
        await page.setRequestInterception(true);
        page.on('request', request => request.respond({status: 200, contentType: 'text/html', body: '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body></body></html>'}));
        await page.goto('https://example.test/admin/users/create');
        await page.setContent(template('admin/create.php'));
        await page.addStyleTag({path: path.join(root, 'public/assets/css/marketing.css')});
        await page.addStyleTag({path: path.join(root, 'public/assets/css/admin-members.css')});
        await page.addScriptTag({path: path.join(root, 'public/assets/js/admin-members.js')});
        assert.equal(await page.$eval('[data-access-free]', el => el.hidden && el.disabled), true);
        await page.select('#access', 'internal');
        assert.equal(await page.$eval('[data-access-paid]', el => el.hidden && el.disabled), true);
        assert.equal(await page.$eval('[data-access-free]', el => el.hidden || el.disabled), false);
        assert.equal(await page.$eval('form', form => new FormData(form).has('amount')), false);
        await page.select('#access', 'paid');
        assert.equal(await page.$eval('form', form => new FormData(form).get('amount')), '9.99');
        for (const width of [1440, 390]) {
            await page.setViewport({width, height: 1000});
            assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
        }
        const token = 'a'.repeat(64);
        await page.goto('https://example.test/account/setup#' + token);
        await page.setContent(template('auth/setup.php'));
        await page.addScriptTag({path: path.join(root, 'public/assets/js/account-setup.js')});
        assert.equal(await page.$eval('#setup-token', el => el.value), token);
        assert.equal(await page.$eval('#setup-submit', el => el.disabled), false);
        assert.equal(await page.evaluate(() => location.hash), '');
        await page.goto('https://example.test/account/setup#invalid');
        await page.setContent(template('auth/setup.php'));
        await page.addScriptTag({path: path.join(root, 'public/assets/js/account-setup.js')});
        assert.equal(await page.$eval('#setup-submit', el => el.disabled), true);
        assert.equal(await page.$eval('#setup-link-error', el => el.hidden), false);
        assert.deepEqual(errors, []);
        console.log('PASS: paid/free form selection, agreed amount, desktop/mobile width, private fragment removal, valid setup token and invalid-link handling.');
    } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
