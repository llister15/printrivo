<?php
namespace App\Controllers;

class AccountSetup extends BaseController
{
    public function index(): string
    {
        $this->response->setHeader('Cache-Control','private, no-store')->setHeader('Referrer-Policy','no-referrer');
        return view('auth/setup');
    }
    public function accept()
    {
        $token=$this->request->getPost('token'); $password=$this->request->getPost('password');
        $confirm=$this->request->getPost('password_confirm');
        if (!is_string($token) || !is_string($password) || strlen($password)>255 || $password!==$confirm) {
            return redirect()->to(site_url('account/setup'))->with('setup_error','Enter matching passwords and reopen your invitation link.');
        }
        try {
            (new \App\Services\AdminMembers())->accept($token,$password);
            return redirect()->to(site_url('login'))->with('message','Your password is set. Log in to open your account.');
        } catch (\InvalidArgumentException $e) {
            return redirect()->to(site_url('account/setup'))->with('setup_error',$e->getMessage().' Reopen your invitation link to try again.');
        } catch (\Throwable) {
            return redirect()->to(site_url('account/setup'))->with('setup_error','This setup link is invalid, expired, or already used. Ask your administrator for a new invitation.');
        }
    }
}
