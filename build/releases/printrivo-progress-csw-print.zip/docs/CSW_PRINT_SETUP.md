# CSW print orders

The Gang Sheet Builder and Image Studio now have a **Send to printer** button. A click sends one finished PNG and creates one order using the signed-in member's name and email. It does not charge the customer. CSW reviews pricing and production in its normal sales workflow.

## Configure

1. In CSW, enable the **DTF webhook** and copy its token. The general order webhook token is separate and will not work for artwork attachments.
2. Add the token to the deployed Printrivo `.env`:

   ```dotenv
   cswprint.token = "PASTE_DTF_WEBHOOK_TOKEN_HERE"
   ```

   The local `.env` and the `env` sample have a blank placeholder. Never put the token in JavaScript, HTML, source control, or a deployment ZIP.
3. Deploy the changed/new files listed below and run `php spark migrate --all` from the Printrivo project directory. The new `print_orders` table records request IDs, payload hashes, rate-limit cooldowns, and receipts; it does not store image data or tokens.
4. Ensure PHP accepts an 8 MB file plus multipart overhead (`upload_max_filesize` at least `8M`, `post_max_size` at least `12M`). Allow sufficient PHP memory for the PNG, base64 copy and HTTP JSON body (at least `128M`).
5. With an eligible subscriber, send a small test PNG from each tool when you are ready to create actual CSW orders. Confirm the attached artwork, customer, dimensions, one-copy quantity and order number in CSW. Repeat the same send to verify it returns the existing order. This live acceptance test has not been performed.

Destination: `https://app.cswprint.com/index.php/webhooks/dtf/orders`.
The token is read only on the server and sent as `X-FlowPress-Token`. Redirects are disabled. The browser sends to Printrivo's authenticated, subscription-protected, CSRF-protected endpoint.

## Artwork and retries

- Gang sheets preserve arrangement, transparency and 300 DPI metadata. Image Studio sends the current full canvas, including text and the mirror setting, with the selected DPI. Export-dialog trim/padding options do not alter the document and do not apply to the Send button.
- CSW's current importer accepts PNG artwork up to **8 MB and 100 MP**. Larger designs remain exportable in Printrivo but are blocked from direct sending with a clear message. Nothing is silently downscaled or stripped of its artwork.
- Requests include dimensions in inches and pixels in CSW's production specifications. The item is a DTF Gang Sheet or Print-ready artwork, quantity one, awaiting CSW pricing review.
- Browser retries retain the same request ID for the same filename, tool, DPI and PNG bytes in the same tab, including reloads when session storage is available. The server checks an immutable payload hash and returns saved receipts; CSW also deduplicates its source/external ID. A new tab may create a new order, so review uncertain orders in CSW before switching tabs or changing artwork.
- HTTP 429 honors CSW's Retry-After value. Network/server errors preserve retry identity. An uncertain result is never shown as success.

## Processing indicator

A full-width strip appears at the top while Image Studio loads, resizes, applies edits or exports, and while either tool prepares/sends a print. It makes the editor inert during processing and cannot be dismissed with Escape. It shows processing stages with an indeterminate animation; upload percentages are measured from actual upload bytes. Resize uses the existing worker architecture where available so the main UI can stay responsive. Reduced-motion preferences are respected.

## Deployment files

```
app/Config/CswPrint.php
app/Config/Routes.php
app/Config/Services.php
app/Controllers/PrintOrders.php
app/Database/Migrations/2026-09-24-090000_CreatePrintOrders.php
app/Services/CswPrintClient.php
app/Services/PrintOrder.php
app/Views/partials/print_order.php
app/Views/tools/gang_sheet.php
app/Views/tools/image_studio.php
public/assets/css/processing-progress.css
public/assets/js/processing-progress.js
public/assets/js/print-order.js
public/assets/js/image-studio.js
public/assets/js/studio-export.js
public/assets/js/studio-processors.js
public/assets/js/studio-preview.js
public/assets/js/studio-worker.js
```

Update the server `.env` in place; do not replace its database, billing or other settings with the local file.

## Validation

- `php vendor/bin/phpunit --no-coverage --filter PrintOrderTest`
- `node tests/js/print-order.test.cjs`
- `node tests/js/studio-limits.test.cjs`
- `node tests/js/builder.test.cjs`

The generated payloads were also accepted by the local CSW `DtfOrderImport` parser for both tools, preserving exact PNG bytes. No live webhook requests were made. Browser visual verification requires a connected browser.
