<?php
namespace App\Services;
use Config\CswPrint;
class CswPrintClient
{
    public function send(array $payload): array
    {
        $config=config('CswPrint');
        if (!$config->ready()) { throw new \RuntimeException('Printing is not connected.'); }
        // The destination is fixed; browser input can never redirect the token.
        $response=service('curlrequest', [], null, null, false)->post(CswPrint::ENDPOINT,[
            'headers'=>['Content-Type'=>'application/json','X-FlowPress-Token'=>$config->token],
            'body'=>json_encode($payload,JSON_THROW_ON_ERROR),
            'timeout'=>60,'connect_timeout'=>10,'http_errors'=>false,'allow_redirects'=>false,
        ]);
        $body=json_decode($response->getBody(),true);
        return ['status'=>$response->getStatusCode(),'body'=>is_array($body)?$body:[],
            'retry_after'=>$response->getHeaderLine('Retry-After')];
    }
}
